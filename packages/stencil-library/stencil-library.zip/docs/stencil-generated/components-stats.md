# Component Statistics Overview

This page provides an overview of statistics related to the components.

## General Component Statistics

| Statistic | Value |
| --- | --- |
| **Total Components** | `31` |
| **Total Props** | `298` |
| **Total Events** | `14` |
| **Total Methods** | `6` |
| **Total Slots** | `44` |
| **Total Features** | `362` |
|   |  |
| **Shadow DOM Components** | `31` |
| **Light DOM Components** | `0` |
| **Components with Props** | `31` |
| **Components with Events** | `7` |
| **Components with Methods** | `2` |
| **Components with Slots** | `19` |

## Detailed Component Statistics

### tnw-accordion
| Feature | Count |
| --- | --- |
| **Props** | `10` |
| **Events** | `1` |
| **Methods** | `0` |
| **Slots** | `3` |

### tnw-accordion-group
| Feature | Count |
| --- | --- |
| **Props** | `1` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-alert
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-anchor
| Feature | Count |
| --- | --- |
| **Props** | `8` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-badge
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-button
| Feature | Count |
| --- | --- |
| **Props** | `11` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `2` |

### tnw-card
| Feature | Count |
| --- | --- |
| **Props** | `19` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `6` |

### tnw-contact-banner
| Feature | Count |
| --- | --- |
| **Props** | `9` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `5` |

### tnw-copyrights-footer
| Feature | Count |
| --- | --- |
| **Props** | `15` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-divider
| Feature | Count |
| --- | --- |
| **Props** | `2` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-footer
| Feature | Count |
| --- | --- |
| **Props** | `9` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `6` |

### tnw-header
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `2` |

### tnw-header-banner
| Feature | Count |
| --- | --- |
| **Props** | `13` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `4` |

### tnw-heading
| Feature | Count |
| --- | --- |
| **Props** | `15` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-icon
| Feature | Count |
| --- | --- |
| **Props** | `11` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-image
| Feature | Count |
| --- | --- |
| **Props** | `10` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-input
| Feature | Count |
| --- | --- |
| **Props** | `17` |
| **Events** | `2` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-items-carousel
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `3` |

### tnw-label
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-list
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-navbar
| Feature | Count |
| --- | --- |
| **Props** | `13` |
| **Events** | `3` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-newsletter-form
| Feature | Count |
| --- | --- |
| **Props** | `11` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-portfolio-grid
| Feature | Count |
| --- | --- |
| **Props** | `4` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-rating
| Feature | Count |
| --- | --- |
| **Props** | `6` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-rows-carousel
| Feature | Count |
| --- | --- |
| **Props** | `2` |
| **Events** | `2` |
| **Methods** | `3` |
| **Slots** | `1` |

### tnw-scroll-to-top
| Feature | Count |
| --- | --- |
| **Props** | `7` |
| **Events** | `2` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-section
| Feature | Count |
| --- | --- |
| **Props** | `10` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `3` |

### tnw-select
| Feature | Count |
| --- | --- |
| **Props** | `9` |
| **Events** | `2` |
| **Methods** | `3` |
| **Slots** | `0` |

### tnw-testimonial-card
| Feature | Count |
| --- | --- |
| **Props** | `12` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `0` |

### tnw-text
| Feature | Count |
| --- | --- |
| **Props** | `14` |
| **Events** | `0` |
| **Methods** | `0` |
| **Slots** | `1` |

### tnw-textarea
| Feature | Count |
| --- | --- |
| **Props** | `18` |
| **Events** | `2` |
| **Methods** | `0` |
| **Slots** | `0` |

