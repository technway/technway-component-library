# tnw-anchor

## Table of Contents

- [Overview](#overview)
- [Properties](#properties)
- [Slots](#slots)
- [Shadow Parts](#shadow-parts)
- [Usage](#usage)

## Overview

The `tnw-anchor` component is a versatile anchor link element that can be used to navigate to other pages or external resources.
This component supports both text content and custom content via a slot, making it flexible for various use cases, such as wrapping other elements like images or icons.

| Detail | Value |
| --- | --- |
| HTML Component Tag | `<tnw-anchor>` |
| React Component Tag | `TnwAnchor` |
| Encapsulation | `shadow` |

<div style="overflow-x: auto;">
## Properties

| Property | Description | Default | Type |
| --- | --- | --- | --- |
| **color** | <div>Sets the color of the text based on the available colors.</div> | `'auto'` | `"auto"` \| `"black"` \| `"gray100"` \| `"gray200"` \| `"gray300"` \| `"gray400"` \| `"gray500"` \| `"gray600"` \| `"gray700"` \| `"gray800"` \| `"gray900"` \| `"inverse"` \| `"light"` \| `"placeholder"` \| `"primary"` \| `"secondary"` \| `"white"` |
| **hideNewTabIcon** | <div>Hides the new tab icon.</div> | `false` | `boolean` |
| **href** | <div>Specifies the URL that the link navigates to. This prop is required.</div> | N/A | `string` |
| **labelAria** | <div>Specifies the aria-label for the anchor, providing an accessible name for screen readers. If not provided, it defaults to the value of the `text` prop or falls back to a custom value if content is slotted.</div> | N/A | `string` |
| **newTab** | <div>Specifies whether the link should open in a new browser tab.</div> | `false` | `boolean` |
| **size** | <div>Sets the font size of the anchor text.</div> | N/A | `"2xl"` \| `"3xl"` \| `"4xl"` \| `"5xl"` \| `"6xl"` \| `"7xl"` \| `"8xl"` \| `"9xl"` \| `"heading"` \| `"lg"` \| `"md"` \| `"sm"` \| `"text"` \| `"xl"` \| `"xs"` |
| **text** | <div>Specifies the text content of the link. If not provided, the content should be provided via the default slot.</div> | N/A | `string` |
| **textDecoration** | <div>Specifies the text decoration line of the anchor text.</div> | `'underline'` | `"line-through"` \| `"none"` \| `"overline"` \| `"underline"` |

</div>

## Shadow Parts

| Part | Description |
| --- | --- |
| **anchor** | The `<a>` element that serves as the anchor link. Use this part for styling the anchor element. |
| **icon** | The `<tnw-icon>` element that displays the "new tab" icon. Only rendered if the property `hideNewTabIcon` is set to `false`. |

## Slots

| Slot | Description |
| --- | --- |
| **default** | Default slot for custom content (e.g., an image, icon, or complex HTML structure). |

## Usage & Examples

### When to use:

- **Basic Links**: Use `tnw-anchor` when you need a standard text-based hyperlink to navigate users to other pages or external resources.
- **Custom Content Links**: The component is also suitable when you want to wrap custom content like images, icons, or cards in a link, providing flexibility beyond simple text links.
- **New Tab Links**: Use `tnw-anchor` to create links that open in a new tab when navigating to external resources, while optionally hiding or displaying the "new tab" icon.

### Use Cases:

1. **Standard Text Link**:
   Use this for regular text-based navigation, such as linking to other websites or internal pages.

   @useStory Standard

2. **Colored Link**:
   You can modify the text color using predefined color options to ensure the link visually aligns with your design theme.

   @useStory PrimaryColor

3. **Link that Opens in a New Tab**:
   When linking to external sites, use this case to open the link in a new browser tab. You can also choose to show or hide the "new tab" icon based on your preferences.

   @useStory OpenInNewTab

4. **Custom Content Inside Anchor**:
   Wrap custom content like images or icons within the anchor tag to create complex, clickable elements, such as a linked image or card. 
   
   **Important for a11y**: When using non-text content like images or icons, ensure that an appropriate `labelAria` is provided. This is crucial for accessibility, as it helps screen readers and other assistive technologies understand the purpose of the link.

   @useStory CustomContent

### Additional Considerations:

- **Accessibility**: The component supports custom `aria-label` properties. If the anchor content is not text-based (e.g., images, icons), always provide an `aria-label` to describe the link's purpose, ensuring it’s accessible to screen readers. If no `labelAria` is provided, it defaults to the `text` prop or falls back to a generic "Link" label.
- **Customizable Text Decoration**: You can easily control the text decoration (`underline`, `overline`, `none`) to match your application's style and requirements.
- **New Tab Behavior**: For external links, the `newTab` option ensures that the link opens safely in a new tab with proper `noopener noreferrer` attributes for security.
- **Dynamic Slot Usage**: If custom content is placed in the slot (e.g., images or complex HTML), ensure the `text` prop is not used simultaneously, and provide a `labelAria` for accessibility.

