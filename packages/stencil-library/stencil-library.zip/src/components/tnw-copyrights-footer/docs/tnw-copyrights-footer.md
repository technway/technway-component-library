# tnw-copyrights-footer

## Table of Contents

- [Overview](#overview)
- [Properties](#properties)
- [Slots](#slots)
- [Shadow Parts](#shadow-parts)
- [Usage](#usage)

## Overview

The `tnw-footer` component displays footer information such as the organization name, copyright years, 
and additional text. The component provides flexible options for colors, text layout, and custom slot content.
It can be customized to display dynamic or static years, as well as pre-defined text before and after the organization name.

| Detail | Value |
| --- | --- |
| HTML Component Tag | `<tnw-copyrights-footer>` |
| React Component Tag | `TnwCopyrightsFooter` |
| Encapsulation | `shadow` |

<div style="overflow-x: auto;">
## Properties

| Property | Description | Default | Type |
| --- | --- | --- | --- |
| **backgroundColor** | <div>The background color for the footer.</div> | `'auto'` | `"auto"` \| `"black"` \| `"inverse"` \| `"light"` \| `"primary"` \| `"secondary"` \| `"white"` |
| **borderTopColor** | <div>The color of the top border of the footer.</div> | `'auto'` | `"auto"` \| `"black"` \| `"inverse"` \| `"light"` \| `"primary"` \| `"secondary"` \| `"white"` |
| **centerContent** | <div>Centering text</div> | `false` | `boolean` |
| **disableInternalContainer** | <div>If `true`, a container class will be added around the content to align it within the page layout. Default is `false`.</div> | `false` | `boolean` |
| **enableSlot** | <div>If true, the footer will render custom content using a slot instead of the default content.</div> | `false` | `boolean` |
| **endYear** | <div>The ending year to display in the footer. If `useCurrentYearAsEndYear` is true, this will default to the current year.</div> | N/A | `number` |
| **organizationName** | <div>The name of the organization to display in the footer.</div> | N/A | `string` |
| **organizationNameColor** | <div>The color of the organization name. Defaults to the same value as `textColor`.</div> | `this.textColor` | `"auto"` \| `"black"` \| `"gray100"` \| `"gray200"` \| `"gray300"` \| `"gray400"` \| `"gray500"` \| `"gray600"` \| `"gray700"` \| `"gray800"` \| `"gray900"` \| `"inverse"` \| `"light"` \| `"placeholder"` \| `"primary"` \| `"secondary"` \| `"white"` |
| **postText** | <div>Text to display after the organization name.</div> | N/A | `string` |
| **preText** | <div>Text to display before the organization name.</div> | N/A | `string` |
| **startYear** | <div>The starting year to display in the footer. If `useCurrentYearAsStartYear` is true, this will default to the current year.</div> | N/A | `number` |
| **textColor** | <div>The text color for the footer content.</div> | `'auto'` | `"auto"` \| `"black"` \| `"gray100"` \| `"gray200"` \| `"gray300"` \| `"gray400"` \| `"gray500"` \| `"gray600"` \| `"gray700"` \| `"gray800"` \| `"gray900"` \| `"inverse"` \| `"light"` \| `"placeholder"` \| `"primary"` \| `"secondary"` \| `"white"` |
| **useCurrentYearAsEndYear** | <div>If true, the ending year will be set to the current year.</div> | `false` | `boolean` |
| **useCurrentYearAsStartYear** | <div>If true, the starting year will be set to the current year.</div> | `false` | `boolean` |
| **useDivAsContainer** | <div>If `true`, the footer will be rendered using a `<div>` element instead of a `<footer>` element. This is useful when this component is used inside a `<footer>` or inside the component `<tnw-footer>`.</div> | `false` | `boolean` |

</div>

## Shadow Parts

| Part | Description |
| --- | --- |
| **container** | No description provided. |
| **content** | No description provided. |
| **footer** | The `footer` element that wraps the entire content of the footer. |

## Slots

| Slot | Description |
| --- | --- |
| **default** | Custom content slot for the footer. When `enableSlot` is true, this slot is used instead of the default content. |

## Usage & Examples

### When to use:

- **Displaying Footer Information**: Use `tnw-footer` to display essential information at the bottom of a webpage, such as organization names, copyright details, and important notes.
- **Dynamic or Static Years**: The component is useful for displaying dynamic years (e.g., "2023 - 2024") or static date ranges.
- **Customizable Footer Layout**: When you need a customizable footer that supports text alignment, background colors, and custom content via slots.

### Use Cases:

1. **Standard Footer with Organization Name and Years**:
   Use this when you want to display your organization's name with a start and end year range, along with optional pretext (e.g., "©") and posttext (e.g., "All Rights Reserved").

   @useStory Standard

2. **Footer with Custom Slot Content**:
   Use this case when you need to fully customize the content of the footer, such as including images, links, or any custom HTML content.

   @useStory WithCustomSlot

3. **Footer with Dynamic Years**:
   Automatically display the current year, which is useful for keeping the footer up to date without manual adjustments.

   @useStory DynamicYears

### Additional Considerations:

- **Custom Colors**: You can easily adjust the text color, background color, and top border color of the footer to match your brand’s design.
- **Custom Slot Content**: When using the slot for custom content, make sure the `enableSlot` prop is set to `true` to render your custom HTML or elements in the footer.
- **Text Alignment**: The footer supports centering the content when the `centerContent` prop is enabled, making it adaptable for different layout needs.


