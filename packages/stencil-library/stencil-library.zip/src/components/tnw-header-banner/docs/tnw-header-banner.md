# tnw-header-banner

## Table of Contents

- [Overview](#overview)
- [Properties](#properties)
- [Slots](#slots)
- [Shadow Parts](#shadow-parts)
- [Usage](#usage)

## Overview

This component is designed to be used inside the `tnw-header`.

The `tnw-header-banner` component creates a customizable banner for headers, featuring headings, subheadings, descriptions, and buttons.
It is designed to align with the theme of the parent header component, making it a cohesive part of the header design.

| Detail | Value |
| --- | --- |
| HTML Component Tag | `<tnw-header-banner>` |
| React Component Tag | `TnwHeaderBanner` |
| Encapsulation | `shadow` |

<div style="overflow-x: auto;">
## Properties

| Property | Description | Default | Type |
| --- | --- | --- | --- |
| **alignment** | <div>Controls the alignment of the banner content. Acceptable values are 'start', 'center', or 'end' to align the content horizontally and vertically within the banner. Default is 'start'.</div> | `'start'` | `"center"` \| `"end"` \| `"left"` \| `"right"` \| `"start"` |
| **buttonLabel** | <div>The label for the banner's button. If not provided, the button content can be customized via the `button` slot.</div> | N/A | `string` |
| **description** | <div>The description text of the banner. It offers additional details beneath the heading and subheading, and can be customized via the `description` slot if needed.</div> | N/A | `string` |
| **enableImageSlot** | <div>Enables the image slot for adding custom images to the banner.</div> | `false` | `boolean` |
| **heading** | <div>The main heading text of the banner. This can be a simple string or passed through a slot using the `heading` slot.</div> | N/A | `string` |
| **imageAlt** | <div>Alternative text for the banner image, improving accessibility.</div> | N/A | `string` |
| **imageBorderRadius** | <div>Controls the border radius of the banner image. It can be set to predefined size types or 'none' for no border.</div> | `'none'` | `"2xl"` \| `"3xl"` \| `"circle"` \| `"default"` \| `"full"` \| `"lg"` \| `"md"` \| `"none"` \| `"sm"` \| `"xl"` \| `"xs"` |
| **imageSrc** | <div>Path to the image file to be displayed in the banner. if provided, the `imageAlt` prop is required.</div> | N/A | `string` |
| **stickyNavbar** | <div>When set to `true`, shifts the banner's vertical alignment to account for a sticky header. This ensures that the banner aligns properly beneath the sticky navbar.</div> | `false` | `boolean` |
| **subheading** | <div>The subheading text of the banner. It provides secondary information under the main heading and can be customized via the `subheading` slot if needed.</div> | N/A | `string` |
| **theme** | <div>Defines the visual theme of the banner, matching it to the header's theme. Options include 'primary', 'secondary', 'inverse', 'auto', 'white', and 'black'. Default is 'auto'.</div> | `'auto'` | `"auto"` \| `"black"` \| `"inverse"` \| `"primary"` \| `"secondary"` \| `"white"` |
| **width** | <div>Specifies the width of the banner. It can be set to predefined size types or 'full' for full-width coverage.</div> | `'full'` | `"full"` \| `"lg"` \| `"md"` \| `"sm"` \| `"xl"` |
| **wrapImage** | <div>Wraps the image in a container for consistency.</div> | `false` | `boolean` |

</div>

## Shadow Parts

| Part | Description |
| --- | --- |
| **button** | The `tnw-button` element or the container for the button slot. |
| **content** | No description provided. |
| **description** | The `tnw-text` element displaying the description of the banner. |
| **heading** | The `tnw-heading` element displaying the main heading of the banner. |
| **image** | No description provided. |
| **image-container** | No description provided. |
| **subheading** | The `tnw-heading` element displaying the subheading of the banner. |

## Slots

| Slot | Description |
| --- | --- |
| **button** | Slot for custom button content if the `buttonLabel` prop is not used. |
| **description** | Slot for custom description content if the `description` prop is not used. |
| **heading** | Slot for custom heading content if the `heading` prop is not used. |
| **subheading** | Slot for custom subheading content if the `subheading` prop is not used. |

## Usage & Examples

### When to use:

- **Header Banners with Call-to-Actions**: Use `tnw-header-banner` to create a visually appealing banner in the header section of your site, featuring a clear call-to-action with a button, heading, and subheading.
- **Promotional or Informational Banners**: Ideal for highlighting promotions, events, or key messages that require attention within a header layout.
- **Customizable Banner Alignment and Layout**: Use this component when you need full control over the alignment, size, and content arrangement in a header banner.

### Use Cases:

1. **Default Header Banner**:
   Use this for a standard banner with a heading, subheading, description, and button in your header section. It's great for drawing attention to important messages or CTAs.

   @useStory Default

2. **Custom Width Banner**:
   When the banner content is smaller and doesn’t need to span the entire width of the screen, this layout allows for a more concise presentation.

   @useStory CustomWidth

3. **Centered Header Banner**:
   For situations where the banner content should be centered both vertically and horizontally, such as for a large hero section or landing page introduction.

   @useStory Centered

### Additional Considerations:

- **Custom Content via Slots**: If you need to insert custom content (e.g., images, videos, or custom HTML), you can use the available slots for heading, subheading, description, and button.
- **Sticky Navigation Compatibility**: The `stickyNavbar` prop ensures that the banner aligns correctly beneath sticky navigation bars, making it perfect for headers with persistent navigation.
- **Theme Matching**: The banner can match the theme of the parent `tnw-header` through its `theme` prop, automatically adjusting text and button colors to fit the overall design.

