# tnw-image

## Table of Contents

- [Overview](#overview)
- [Properties](#properties)
- [Shadow Parts](#shadow-parts)
- [Usage](#usage)

## Overview

The `tnw-image` component is used to display images with optional captions, lazy loading, and customizable styles. 
It supports various properties to control the image source, dimensions, and appearance.

| Detail | Value |
| --- | --- |
| HTML Component Tag | `<tnw-image>` |
| React Component Tag | `TnwImage` |
| Encapsulation | `shadow` |

<div style="overflow-x: auto;">
## Properties

| Property | Description | Default | Type |
| --- | --- | --- | --- |
| **BorderRadius** | <div>Determines the border radius of the image.</div> | `'default'` | `"2xl"` \| `"3xl"` \| `"circle"` \| `"default"` \| `"full"` \| `"lg"` \| `"md"` \| `"none"` \| `"sm"` \| `"xl"` \| `"xs"` |
| **alt** | <div>The alternative text for the image, used for accessibility.</div> | N/A | `string` |
| **aspectRatio** | <div>The aspect ratio of the image (width / height). Useful for maintaining image proportions.</div> | `"initial"` | `"16_9"` \| `"1_1"` \| `"21_9"` \| `"3_4"` \| `"4_3"` \| `"9_16"` \| `"9_21"` \| `"initial"` |
| **caption** | <div>An optional caption to be displayed below the image.</div> | `''` | `string` |
| **heightSize** | <div>The height size of the image.</div> | N/A | `"full"` \| `"lg"` \| `"md"` \| `"sm"` |
| **lazyLoading** | <div>If `true`, the image will use lazy loading, loading only when it is about to be visible in the viewport.</div> | `false` | `boolean` |
| **objectFit** | <div>Defines how the image should be resized to fit its container. This controls the CSS `object-fit` property.</div> | N/A | `"contain"` \| `"cover"` \| `"fill"` \| `"none"` \| `"scale-down"` |
| **objectPosition** | <div>The object position of the image. This defines how the image is positioned within its container.</div> | `"initial"` | `"bottom"` \| `"bottom-left"` \| `"bottom-right"` \| `"center"` \| `"center-bottom"` \| `"center-left"` \| `"center-right"` \| `"center-top"` \| `"initial"` \| `"left"` \| `"left-bottom"` \| `"left-top"` \| `"right"` \| `"right-bottom"` \| `"right-top"` \| `"top"` \| `"top-left"` \| `"top-right"` |
| **src** | <div>The source URL/Path of the image.</div> | N/A | `string` |
| **widthSize** | <div>The width size of the image.</div> | `'full'` | `"full"` \| `"lg"` \| `"md"` \| `"sm"` |

</div>

## Shadow Parts

| Part | Description |
| --- | --- |
| **figcaption** | The `<figcaption>` element for the image caption (if provided). |
| **figure** | The container `<figure>` element for the image and optional caption. |
| **image** | The main `<img>` element rendering the image. |

## Usage & Examples

### When to use:

- **Displaying Images with Optional Captions**: Use `tnw-image` to display images with optional captions for enhanced context or descriptions.
- **Custom Sizing and Aspect Ratios**: This component is ideal when you need control over the dimensions and aspect ratio of images to fit specific layouts or designs.
- **Optimized Image Loading**: For performance optimization, use the lazy loading feature to load images only when they are about to come into the viewport.

### Use Cases:

1. **Standard Image**:
   Use this case for displaying a basic image, such as a product image or media in a blog post.

   @useStory Standard

2. **Image with Caption**:
   When you need to provide additional context or information below the image, use this option with a caption.

   @useStory ImageWithCaption

3. **Image with Custom Aspect Ratio**:
   For maintaining specific proportions (e.g., 16:9 or 4:3) in your image display, use this case.

   @useStory AspectRatioImage

4. **Image with Object Fit (Cover)**:
   Use this when the image should cover the entire space of its container, such as for full-width hero images or banners.

   @useStory ObjectFitCover

### Additional Considerations:

- **Lazy Loading**: For performance optimization, enable lazy loading so that images load only when they are near the viewport. This is particularly useful for long pages or content-heavy websites.
- **Customizable Sizes and Ratios**: You can easily control the width, height, and aspect ratio to adapt the image to different layouts, ensuring responsive behavior across devices.
- **Object Fit and Position**: The `objectFit` and `objectPosition` properties allow fine control over how the image scales and positions itself within the container, ensuring a precise layout fit.

