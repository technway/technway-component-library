export const iconSetupStyles = `
[class^="icon-"],
[class*=" icon-"] {
    /* use !important to prevent issues with browser extensions that change fonts */
    font-family: 'icomoon' !important;
    speak: never;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;

    /* Better Font Rendering =========== */
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
`;

export const iconClassNames = `
.icon-tnw-code:before {
  content: "\\e903";
}
.icon-tnw-mute:before {
  content: "\\e904";
}
.icon-tnw-quotes-left:before {
  content: "\\e977";
}
.icon-tnw-quotes-right:before {
  content: "\\e978";
}
.icon-tnw-search-2:before {
  content: "\\e986";
}
.icon-tnw-volume-medium:before {
  content: "\\ea27";
}
.icon-tnw-wordpress:before {
  content: "\\eab4";
}
.icon-tnw-soundcloud:before {
  content: "\\eac3";
}
.icon-tnw-pinterest-circle1:before {
  content: "\\ead1";
}
.icon-tnw-pinterest-circle-outline:before {
  content: "\\ead2";
}
.icon-tnw-dribbble-brand:before {
  content: "\\e906";
  color: #ea4c89;
}
.icon-tnw-behance-brand:before {
  content: "\\e907";
  color: #1769ff;
}
.icon-tnw-trello-brand:before {
  content: "\\e908";
  color: #0079bf;
}
.icon-tnw-trustpilot-brand:before {
  content: "\\e909";
  color: #00b67a;
}
.icon-tnw-stackexchange-brand:before {
  content: "\\e90a";
  color: #1e5397;
}
.icon-tnw-stackoverflow-brand:before {
  content: "\\e90b";
  color: #fe7a16;
}
.icon-tnw-dev-brand:before {
  content: "\\e90c";
}
.icon-tnw-codepen-brand:before {
  content: "\\e90d";
}
.icon-tnw-github-brand:before {
  content: "\\e90e";
}
.icon-tnw-slack-brand:before {
  content: "\\e90f";
  color: #4a154b;
}
.icon-tnw-reddit-brand:before {
  content: "\\e910";
  color: #ff4500;
}
.icon-tnw-tiktok-brand:before {
  content: "\\e911";
}
.icon-tnw-whatsapp-brand:before {
  content: "\\e912";
  color: #25d366;
}
.icon-tnw-snapchat-brand:before {
  content: "\\e913";
  color: #fffc00;
}
.icon-tnw-pinterest-brand:before {
  content: "\\e914";
  color: #bd081c;
}
.icon-tnw-youtube-brand:before {
  content: "\\e915";
  color: #f00;
}
.icon-tnw-linkedin-brand:before {
  content: "\\e916";
  color: #0077b5;
}
.icon-tnw-x-brand:before {
  content: "\\e917";
}
.icon-tnw-tnwitter-brand:before {
  content: "\\e917";
}
.icon-tnw-facebook-brand:before {
  content: "\\e918";
  color: #1877f2;
}
.icon-tnw-gmail-brand:before {
  content: "\\e919";
  color: #d14836;
}
.icon-tnw-100ning:before {
  content: "\\e91a";
}
.icon-tnw-100ning-outline:before {
  content: "\\e91b";
}
.icon-tnw-inbox-download:before {
  content: "\\e91c";
}
.icon-tnw-inbox-download-outline:before {
  content: "\\e91d";
}
.icon-tnw-folder-download:before {
  content: "\\e91e";
}
.icon-tnw-folder-download-outline:before {
  content: "\\e91f";
}
.icon-tnw-cloud-download:before {
  content: "\\e920";
}
.icon-tnw-cloud-download-outline:before {
  content: "\\e921";
}
.icon-tnw-inbox-upload:before {
  content: "\\e922";
}
.icon-tnw-inbox-upload-outline:before {
  content: "\\e923";
}
.icon-tnw-folder-upload:before {
  content: "\\e924";
}
.icon-tnw-folder-upload-outline:before {
  content: "\\e925";
}
.icon-tnw-cloud-upload:before {
  content: "\\e926";
}
.icon-tnw-cloud-upload-outline:before {
  content: "\\e927";
}
.icon-tnw-woman-avatar-outline:before {
  content: "\\e928";
}
.icon-tnw-man-avatar-outline:before {
  content: "\\e929";
}
.icon-tnw-moon:before {
  content: "\\e901";
}
.icon-tnw-globe-2:before {
  content: "\\e92a";
}
.icon-tnw-heart:before {
  content: "\\e92b";
}
.icon-tnw-vcard:before {
  content: "\\e92c";
}
.icon-tnw-link:before {
  content: "\\e900";
}
.icon-tnw-pinterest:before {
  content: "\\e963";
}
.icon-tnw-dribbble:before {
  content: "\\e92e";
}
.icon-tnw-behance:before {
  content: "\\e92f";
}
.icon-tnw-emoji-sad:before {
  content: "\\e930";
}
.icon-tnw-emoji-neutral:before {
  content: "\\e931";
}
.icon-tnw-emoji-happy:before {
  content: "\\e932";
}
.icon-tnw-emoji-flirt:before {
  content: "\\e933";
}
.icon-tnw-youtube:before {
  content: "\\e934";
}
.icon-tnw-question-mark-circle:before {
  content: "\\e935";
}
.icon-tnw-question-mark:before {
  content: "\\e936";
}
.icon-tnw-lifebuoy:before {
  content: "\\e937";
}
.icon-tnw-pencil:before {
  content: "\\e938";
}
.icon-tnw-paper-plane:before {
  content: "\\e939";
}
.icon-tnw-at:before {
  content: "\\e93a";
}
.icon-tnw-envelope-21:before {
  content: "\\e93b";
}
.icon-tnw-inbox-download-2:before {
  content: "\\e93c";
}
.icon-tnw-cloud-upload-2:before {
  content: "\\e93d";
}
.icon-tnw-inbox-upload-2:before {
  content: "\\e93e";
}
.icon-tnw-select-arrows:before {
  content: "\\e93f";
}
.icon-tnw-close-square:before {
  content: "\\e940";
}
.icon-tnw-add-2:before {
  content: "\\e942";
}
.icon-tnw-trash:before {
  content: "\\e943";
}
.icon-tnw-shopping-bag:before {
  content: "\\e944";
}
.icon-tnw-shopping-cart:before {
  content: "\\e945";
}
.icon-tnw-globe-21:before {
  content: "\\e946";
}
.icon-tnw-sun:before {
  content: "\\e947";
}
.icon-tnw-bolt:before {
  content: "\\e949";
}
.icon-tnw-pencil-2:before {
  content: "\\e94a";
}
.icon-tnw-send:before {
  content: "\\e94b";
}
.icon-tnw-arrow-thin-up:before {
  content: "\\e94c";
}
.icon-tnw-arrow-thin-right:before {
  content: "\\e94d";
}
.icon-tnw-arrow-thin-left:before {
  content: "\\e94e";
}
.icon-tnw-arrow-thin-down:before {
  content: "\\e94f";
}
.icon-tnw-arrow-right:before {
  content: "\\e950";
}
.icon-tnw-arrow-left:before {
  content: "\\e951";
}
.icon-tnw-arrow-down:before {
  content: "\\e952";
}
.icon-tnw-arrow-up:before {
  content: "\\e953";
}
.icon-tnw-close-circle:before {
  content: "\\e954";
}
.icon-tnw-close-circle-outline:before {
  content: "\\e955";
}
.icon-tnw-close:before {
  content: "\\e956";
}
.icon-tnw-checkmark-circle-outline:before {
  content: "\\e957";
}
.icon-tnw-checkmark:before {
  content: "\\e958";
}
.icon-tnw-minus-circle:before {
  content: "\\e959";
}
.icon-tnw-minus-circle-outline:before {
  content: "\\e95a";
}
.icon-tnw-trash-2:before {
  content: "\\e95b";
}
.icon-tnw-settings-2:before {
  content: "\\e95c";
}
.icon-tnw-menu:before {
  content: "\\e95d";
}
.icon-tnw-search:before {
  content: "\\e95e";
}
.icon-tnw-cloud-download-outline-2:before {
  content: "\\e95f";
}
.icon-tnw-add-circle-outline:before {
  content: "\\e960";
}
.icon-tnw-cart-outline:before {
  content: "\\e961";
}
.icon-tnw-sun-outline:before {
  content: "\\e962";
}
.icon-tnw-heart-outline:before {
  content: "\\e966";
}
.icon-tnw-heart-2:before {
  content: "\\e967";
}
.icon-tnw-arrow-loop:before {
  content: "\\e968";
}
.icon-tnw-arrow-maximise:before {
  content: "\\e969";
}
.icon-tnw-arrow-minimise:before {
  content: "\\e96a";
}
.icon-tnw-arrow-shuffle:before {
  content: "\\e96b";
}
.icon-tnw-arrow-move:before {
  content: "\\e96c";
}
.icon-tnw-arrow-back:before {
  content: "\\e96d";
}
.icon-tnw-arrow-forward:before {
  content: "\\e96e";
}
.icon-tnw-cog-outline:before {
  content: "\\e96f";
}
.icon-tnw-user-add-outline:before {
  content: "\\e970";
}
.icon-tnw-user-delete-outline:before {
  content: "\\e971";
}
.icon-tnw-user-outline:before {
  content: "\\e972";
}
.icon-tnw-user-delete:before {
  content: "\\e973";
}
.icon-tnw-user-add:before {
  content: "\\e974";
}
.icon-tnw-user:before {
  content: "\\e975";
}
.icon-tnw-facebook-circle:before {
  content: "\\e964";
}
.icon-tnw-globe:before {
  content: "\\e976";
}
.icon-tnw-cloud-download-2:before {
  content: "\\e97a";
}
.icon-tnw-chevron-large-right:before {
  content: "\\e97b";
}
.icon-tnw-chevron-large-left:before {
  content: "\\e97c";
}
.icon-tnw-triangle-right:before {
  content: "\\e97d";
}
.icon-tnw-triangle-left:before {
  content: "\\e97e";
}
.icon-tnw-triangle-up:before {
  content: "\\e97f";
}
.icon-tnw-triangle-down:before {
  content: "\\e980";
}
.icon-tnw-chevron-up:before {
  content: "\\e981";
}
.icon-tnw-chevron-right:before {
  content: "\\e982";
}
.icon-tnw-chevron-left:before {
  content: "\\e983";
}
.icon-tnw-chevron-down:before {
  content: "\\e984";
}
.icon-tnw-alarm:before {
  content: "\\e985";
}
.icon-tnw-add-call:before {
  content: "\\e987";
}
.icon-tnw-library-add:before {
  content: "\\e988";
}
.icon-tnw-queue:before {
  content: "\\e988";
}
.icon-tnw-auto-delete:before {
  content: "\\e989";
}
.icon-tnw-remove-shopping-cart:before {
  content: "\\e98a";
}
.icon-tnw-add-shopping-cart:before {
  content: "\\e98b";
}
.icon-tnw-settings:before {
  content: "\\e98c";
}
.icon-tnw-menu-open:before {
  content: "\\e98d";
}
.icon-tnw-moon-outline1:before {
  content: "\\e902";
}
.icon-tnw-linkedin-outline:before {
  content: "\\e965";
}
.icon-tnw-trello-outline:before {
  content: "\\e98e";
}
.icon-tnw-codepen:before {
  content: "\\e990";
}
.icon-tnw-github-outline:before {
  content: "\\e991";
}
.icon-tnw-slack-outline:before {
  content: "\\e992";
}
.icon-tnw-youtube-outline:before {
  content: "\\e993";
}
.icon-tnw-instagram-outline:before {
  content: "\\e995";
}
.icon-tnw-facebook-outline:before {
  content: "\\e996";
}
.icon-tnw-life-buoy:before {
  content: "\\e997";
}
.icon-tnw-question-mark-circle-outline:before {
  content: "\\e998";
}
.icon-tnw-bell-off:before {
  content: "\\e999";
}
.icon-tnw-bell:before {
  content: "\\e99a";
}
.icon-tnw-edit-2:before {
  content: "\\e99b";
}
.icon-tnw-edit-1:before {
  content: "\\e99c";
}
.icon-tnw-edit:before {
  content: "\\e99d";
}
.icon-tnw-envelope-2:before {
  content: "\\e99e";
}
.icon-tnw-download-cloud-3:before {
  content: "\\e99f";
}
.icon-download4:before {
  content: "\\e9a0";
}
.icon-tnw-upload-cloud-3:before {
  content: "\\e9a1";
}
.icon-tnw-upload-cloud-4:before {
  content: "\\e9a2";
}
.icon-tnw-arrow-down-left:before {
  content: "\\e9a3";
}
.icon-tnw-arrow-down-right:before {
  content: "\\e9a4";
}
.icon-tnw-arrow-up-left:before {
  content: "\\e9a5";
}
.icon-tnw-arrow-right-circle:before {
  content: "\\e9a6";
}
.icon-tnw-arrow-left-circle:before {
  content: "\\e9a7";
}
.icon-tnw-arrow-down-circle:before {
  content: "\\e9a8";
}
.icon-tnw-arrow-up-circle:before {
  content: "\\e9a9";
}
.icon-tnw-arrow-up-right:before {
  content: "\\e9aa";
}
.icon-tnw-arrow-short-right:before {
  content: "\\e9ab";
}
.icon-tnw-arrow-short-left:before {
  content: "\\e9ac";
}
.icon-tnw-arrow-short-down:before {
  content: "\\e9ad";
}
.icon-tnw-arrow-short-up:before {
  content: "\\e9ae";
}
.icon-tnw-checkmark-circle-outline-2:before {
  content: "\\e9af";
}
.icon-tnw-checkmark-square-outline:before {
  content: "\\e9b0";
}
.icon-tnw-checkmark-2:before {
  content: "\\e9b1";
}
.icon-tnw-minimize:before {
  content: "\\e9b2";
}
.icon-tnw-file-minus:before {
  content: "\\e9b3";
}
.icon-tnw-minus-circle-outline-2:before {
  content: "\\e9b4";
}
.icon-tnw-minus-square-outline:before {
  content: "\\e9b5";
}
.icon-tnw-minimize2:before {
  content: "\\e9b6";
}
.icon-tnw-minus:before {
  content: "\\e9b7";
}
.icon-tnw-user-minus-outline-3:before {
  content: "\\e9b8";
}
.icon-tnw-folder-minus:before {
  content: "\\e9b9";
}
.icon-tnw-file-plus:before {
  content: "\\e9ba";
}
.icon-tnw-add-square-outline:before {
  content: "\\e9bb";
}
.icon-tnw-add-circle-outline1:before {
  content: "\\e9bc";
}
.icon-tnw-add:before {
  content: "\\e9bd";
}
.icon-tnw-folder-plus:before {
  content: "\\e9be";
}
.icon-tnw-trash-21:before {
  content: "\\e9bf";
}
.icon-tnw-shopping-bag-1:before {
  content: "\\e9c0";
}
.icon-tnw-shopping-cart-2:before {
  content: "\\e9c1";
}
.icon-tnw-user-delete-outline-3:before {
  content: "\\e9c2";
}
.icon-tnw-user-check-outline:before {
  content: "\\e9c3";
}
.icon-tnw-users-3:before {
  content: "\\e9c4";
}
.icon-tnw-group-3:before {
  content: "\\e9c4";
}
.icon-tnw-user-add-outline-3:before {
  content: "\\e9c6";
}
.icon-tnw-user-outline-3:before {
  content: "\\e9c7";
}
.icon-tnw-share:before {
  content: "\\e9c8";
}
.icon-tnw-home:before {
  content: "\\e9c9";
}
.icon-tnw-moon-outline:before {
  content: "\\e905";
}
.icon-tnw-linkedin:before {
  content: "\\e979";
}
.icon-tnw-facebook:before {
  content: "\\e994";
}
.icon-tnw-trello:before {
  content: "\\e9ca";
}
.icon-tnw-globe1:before {
  content: "\\e9cb";
}
.icon-tnw-stack-exchange:before {
  content: "\\e9cc";
}
.icon-tnw-stack-overflow:before {
  content: "\\e9cd";
}
.icon-tnw-github:before {
  content: "\\e9ce";
}
.icon-tnw-whatsapp:before {
  content: "\\e9cf";
}
.icon-tnw-snapchat:before {
  content: "\\e9d0";
}
.icon-tnw-snapchat-circle:before {
  content: "\\e9d1";
}
.icon-tnw-pinterest-circle:before {
  content: "\\e9d2";
}
.icon-tnw-pencil-square:before {
  content: "\\e9d4";
}
.icon-tnw-envelope-open:before {
  content: "\\e9d5";
}
.icon-tnw-envelope:before {
  content: "\\e9d6";
}
.icon-tnw-download:before {
  content: "\\e9d7";
}
.icon-tnw-cloud-download-3:before {
  content: "\\e9d8";
}
.icon-tnw-upload:before {
  content: "\\e9d9";
}
.icon-tnw-cloud-upload-3:before {
  content: "\\e9da";
}
.icon-tnw-add-square:before {
  content: "\\e9db";
}
.icon-tnw-user-outline-2:before {
  content: "\\e9dc";
}
.icon-tnw-user-circle-outline:before {
  content: "\\e9dd";
}
.icon-tnw-user-circle:before {
  content: "\\e9de";
}
.icon-tnw-user-delete-2:before {
  content: "\\e9df";
}
.icon-tnw-user-secret:before {
  content: "\\e9e0";
}
.icon-tnw-group:before {
  content: "\\e9e2";
}
.icon-tnw-users:before {
  content: "\\e9e2";
}
.icon-tnw-user-add-2:before {
  content: "\\e9e3";
}
.icon-tnw-user-2:before {
  content: "\\e9e4";
}
`;